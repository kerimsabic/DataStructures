package task2;

public class RedBlackTree <Key extends Comparable<Key>, Value> {
    private Node<Key, Value> root;
    private static final boolean RED = true;
    private static final boolean BLACK = false;
    public int numSteps = 0;
    private int redLinksCount = 0;

    public Value get(Key key) {
        Node<Key, Value> x = root;				// 1
        numSteps = 0;

        while (x != null) {						// 2
            numSteps++;
            int cmp = key.compareTo(x.key);		// 3
            if (cmp < 0) {						// 4
                x = x.left;						// 4
            } else if (cmp > 0) {				// 5
                x = x.right;					// 5
            } else {							// 6
                return x.value;					// 6
            }
        }

        return null;
    }

    private Node<Key, Value> rotateLeft(Node<Key, Value> h) {
        Node<Key, Value> x = h.right;
        h.right = x.left;
        x.left = h;
        x.color = h.color;
        h.color = RED;
        return x;
    }


    private Node<Key, Value> rotateRight(Node<Key, Value> h) {
        Node<Key, Value> x = h.left;
        h.left = x.right;
        x.right = h;
        x.color = h.color;
        h.color = RED;
        return x;
    }

    private void flipColors(Node<Key, Value> h) {
        h.color = RED;
        h.right.color = BLACK;
        h.left.color = BLACK;
    }
    private boolean isRed(Node<Key, Value> x) {
        if (x == null) {
            return false;
        }
        return x.color == RED;
    }



    public void put(Key key, Value value) {
        root = put(root, key, value);
    }

    private Node<Key, Value> put(Node<Key, Value> h, Key key, Value value) {
        if (h == null) {
            return new Node<Key, Value>(key, value, RED);
        }

        int cmp = key.compareTo(h.key);
        if (cmp < 0) {
            h.left = put(h.left, key, value);
        } else if (cmp > 0) {
            h.right = put(h.right, key, value);
        } else {
            h.value = value;
        }

        if (isRed(h.right) && !isRed(h.left)) {
            h = rotateLeft(h);
        }
        if (isRed(h.left) && isRed(h.left.left)) {
            h = rotateRight(h);
        }
        if (isRed(h.left) && isRed(h.right)) {
            flipColors(h);
        }

        return h;
    }


    public int countRedLinks() {
        redLinksCount = 0;
        countRedLinks(root);
        return redLinksCount;
    }

    private void countRedLinks(Node<Key, Value> x) {
        if (x == null) {
            return;
        }

        if (isRed(x.left)) {
            redLinksCount++;
        }
        if (isRed(x.right)) {
            redLinksCount++;
        }

        countRedLinks(x.left);
        countRedLinks(x.right);
    }


}
