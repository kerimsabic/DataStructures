package task2;

import task1.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileUtils {

    public static RedBlackTree<Integer, Student> readFile(String filePath) throws FileNotFoundException {
        RedBlackTree<Integer, Student> tree = new RedBlackTree<>();

        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(";");

                int studentId = Integer.parseInt(data[0]);
                String fullName = data[1];
                String dateOfBirth = data[2];
                String universityName = data[3];
                String departmentCode = data[4];
                String departmentName = data[5];
                int yearOfEnrollment = Integer.parseInt(data[6]);


                Student student = new Student(studentId, fullName, dateOfBirth, universityName,
                        departmentCode, departmentName, yearOfEnrollment);

                tree.put(studentId, student);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return tree;

    }
}
