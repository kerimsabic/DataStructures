package task1;


import java.io.IOException;
import java.util.Scanner;

public class StudentSearchV1 {

    public static void main(String[] args) throws IOException {
        Student[] students = FileUtils.readFile("src/main/java/task1/Global_University_Students.csv");
        System.out.println("Loading the students...");
        MergeSort.sort(students);
        System.out.println("Sorting the students...");


        FileUtils.writeToFile(students, "sorted_students.csv");
        System.out.println("Saving the sorted file...");
        System.out.println("====================================");
        System.out.println("System is ready");
        System.out.println();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter a student ID to search (or -1 to exit): ");
            int studentId = scanner.nextInt();

            if (studentId == -1) {
                System.out.println("Thank you for using student search system.");
                break;
            }


            int index = BinarySearch.search(students, studentId);

            if (index != -1) {

                Student student = students[index];
                System.out.println("Student successfully found!");
                System.out.println();
                System.out.println("Student ID: " + student.getStudentId());
                System.out.println("Full Name: " + student.getFullName());
                System.out.println("Date of Birth: " + student.getDateOfBirth());
                System.out.println("University: " + student.getUniversityName());
                System.out.println("Department Code: " + student.getDepartmentCode());
                System.out.println("Department Name: " + student.getDepartmentName());
                System.out.println("Year of Enrolment: " + student.getYearOfEnrollment());
                System.out.println();
                System.out.println("Student was retrieved in: " + BinarySearch.numSteps+" steps");
                System.out.println();
            } else {
                System.out.println("Student with requested ID does not exist");
                System.out.println("Search was completed in: " + BinarySearch.numSteps+" steps");
                System.out.println();
                System.out.println();
            }
        }


        scanner.close();

    }
}
