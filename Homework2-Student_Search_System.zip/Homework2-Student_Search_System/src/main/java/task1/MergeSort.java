package task1;

import java.util.Comparator;

public class MergeSort {

    public static void sort(Student[] students) {
        Student[] aux = new Student[students.length];
        sort(students, aux, 0, students.length - 1);

    }

    private static void sort(Student[] students, Student[] aux, int low, int high) {
        if (high <= low) {
            return;
        }

        int mid = low + (high - low) / 2;
        sort(students, aux, low, mid);
        sort(students, aux, mid + 1, high);
        merge(students, aux, low, mid, high);
    }

    private static void merge(Student[] students, Student[] aux, int low, int mid, int high) {

        for (int k = low; k <= high; k++) {
            aux[k] = students[k];
        }

        int i = low;
        int j = mid + 1;
        for (int k = low; k <= high; k++) {
            if (i > mid) {
                students[k] = aux[j++];
            } else if (j > high) {
                students[k] = aux[i++];
            } else if (less(aux[j].getStudentId(),aux[i].getStudentId())) {
                students[k] = aux[j++];
            } else {
                students[k] = aux[i++];
            }
        }
    }




    public static boolean less(int v, int w) {
        return v < w;
    }


    public static void swap (int[] elements, int a, int b) {
        int tmp = elements[a];
        elements[a] = elements[b];
        elements[b] = tmp;
    }
}
