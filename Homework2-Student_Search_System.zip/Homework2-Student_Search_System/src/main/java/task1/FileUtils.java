package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileUtils {

    public static Student[] readFile(String filePath) throws FileNotFoundException {
        List<Student> students = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(";");
                int studentId = Integer.parseInt(data[0]);
                String fullName = data[1];
                String dateOfBirth = data[2];
                String universityName = data[3];
                String departmentCode = data[4];
                String departmentName = data[5];
                int yearOfEnrollment = Integer.parseInt(data[6]);

                Student student = new Student(studentId, fullName, dateOfBirth, universityName, departmentCode, departmentName, yearOfEnrollment);
                students.add(student);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return students.toArray(new Student[0]);
    }

    public static void writeToFile(Student[] students, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            for (Student student : students) {
                writer.write(student.getStudentId() + ";" +
                        student.getFullName() + ";" +
                        student.getDateOfBirth() + ";" +
                        student.getUniversityName() + ";" +
                        student.getDepartmentCode() + ";" +
                        student.getDepartmentName() + ";" +
                        student.getYearOfEnrollment() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
